import google.generativeai as genai

genai.configure(api_key=api_key)
